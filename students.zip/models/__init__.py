from . import student_details
from . import class_room
from . import branches
from . import courses

